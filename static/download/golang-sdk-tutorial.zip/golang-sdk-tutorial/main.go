package main

import (
	"github.com/LoginRadius/go-sdk"
	"github.com/LoginRadius/go-sdk/api/authentication"
	"github.com/julienschmidt/httprouter"
	"log"
	"net/http"
)

func main() {
	router := httprouter.New()

	config := loginradius.Config{
		ApiKey:    "{{ LoginRadius API Key }}",
		ApiSecret: "{{ LoginRadius API Secret }}",
	}

	router.GET("/", func (w http.ResponseWriter, r *http.Request, _ httprouter.Params) {
		accessToken := r.URL.Query().Get("token")
		client, err := loginradius.NewLoginradius(&config, map[string]string{"token":accessToken})
		if err!=nil{
			panic(err)
		}
		authAPI := lrauthentication.Loginradius{Client: client}
		profile, err := authAPI.GetAuthReadProfilesByToken()
		if err!=nil{
			panic(err)
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(profile.Body))
	})
	log.Fatal(http.ListenAndServe(":3000", router))
}