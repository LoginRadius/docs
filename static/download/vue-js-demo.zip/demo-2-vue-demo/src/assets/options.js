var commonOptions = {};
commonOptions.apiKey = 'apiKey';
commonOptions.appName = 'apiName';
commonOptions.sott = 'sott';
commonOptions.hashTemplate = true;
commonOptions.returnURL ="returnURL";
commonOptions.verificationUrl= 'localhost:8080';
var  LRObject = new LoginRadiusV2(commonOptions);