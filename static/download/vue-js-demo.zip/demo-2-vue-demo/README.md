# LoginRadius Demo

> A demo project utilizing the JS Widgets from LoginRadius for the Vue framework.

## Getting Started
``` bash
# install dependencies
npm install

# setup credentials
goto the directory src/assets/options.js and fill in the required fields

# serve with hot reload at localhost:8080
npm run dev
```

# Features Supported
1. Login
2. Register
3. Resend Email Verification
4. Social Login
