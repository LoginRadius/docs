var commonOptions = {};
commonOptions.apiKey = 'apikey here';
commonOptions.appName = 'sitename here';
commonOptions.sott = 'sott here';
commonOptions.hashTemplate = true;
commonOptions.verificationUrl= 'localhost:8080';
var  LRObject = new LoginRadiusV2(commonOptions);