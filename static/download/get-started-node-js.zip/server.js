var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var app = express();
var PORT = 3000;
app.use(bodyParser.urlencoded({
  extended: true
}));

 var config = {
      apiDomain: 'api.lrinternal.com',
      apiKey: '',
      apiSecret: '',
      siteName: '',
	  apiRequestSigning: false,
	   proxy:{
        host:'',
        port:'',
        user:'',
        password:''
     }
  }
var lrv2 = require('loginradius-sdk')(config);

// get user profile 
app.get('/', function(req, res) {
    var fields = null; //Optional

    lrv2.authenticationApi.getProfileByAccessToken(req.query.token, fields).then((response) => {
        res.json(response);   
       }).catch((error) => {
        res.json({'ErrorMessage':error	});   
       });
  });


app.listen(PORT, () => console.log('App can be accessed at localhost:' + PORT));