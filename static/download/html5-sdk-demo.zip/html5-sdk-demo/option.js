
var commonOptions = {};
commonOptions.apiKey = "<Your API Key>";
commonOptions.appName = "<Your App Name>";
commonOptions.hashTemplate= true;
commonOptions.sott ="<Your SOTT>";
commonOptions.returnUrl="<Enter a URL to redirect to after logging in>";
var path = window.location.href;
commonOptions.verificationUrl = path.replace(path.substr(path.lastIndexOf('/')), "/email-verification.html");
commonOptions.resetPasswordUrl = path.replace(path.substr(path.lastIndexOf('/')), "/reset-password.html");
var LRObject= new LoginRadiusV2(commonOptions);
