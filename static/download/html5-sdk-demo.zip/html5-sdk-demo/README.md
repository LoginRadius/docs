# demo
Quick Demo Implementation for LoginRadius' Customer Registration Service and Social Login APIs and Front Interfaces.

### Usage

1. Open option.js
2. Fill in your LoginRadius API Key and Site Name respectively.
3. Everything should just start working

